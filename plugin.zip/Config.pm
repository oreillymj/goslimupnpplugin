package Plugins::GoSlimPlayer::Config;

# Reading and writing GoSlimPlayer's config file, and turning the settings form into it.
# No LMS code in here, so it can be tested on its own (plugin/t/config.t).
#
# The file is the one GoSlimPlayer's -u reads:
#   { "server": "host[:port]", "players": [ { "name": "...", "mac": "aa:bb:...", ... } ] }
# A player key the form leaves empty is left out of the file, so GoSlimPlayer's own default
# (its command-line flag) applies.

use strict;

use File::Basename qw(dirname);
use File::Path qw(make_path);
use JSON::XS ();

# The form's fields for each player, and what they hold.
#   int / num : a number, or empty for GoSlimPlayer's default
#   tri       : 'default' | 'on' | 'off'
use constant INT_FIELDS => {
	volume_offset => [-100, 100],
	volume_max    => [0, 100],
	http_port     => [0, 65535],
};
use constant TRI_FIELDS => [qw(decodeaudio resampleaudio autoresume icy)];

# Every key this page edits; anything else in an entry is kept untouched.
use constant OWN_KEYS => [qw(name mac enabled buffer_seconds), keys %{ INT_FIELDS() }, @{ TRI_FIELDS() }];

my $json = JSON::XS->new->utf8->pretty->canonical;

# aa:bb:cc:dd:ee:ff from the usual ways of writing a MAC, or '' if it isn't one.
sub normMAC {
	my $s = lc(shift // '');
	$s =~ s/[\s:\-.]//g;
	return '' unless $s =~ /^[0-9a-f]{12}\z/;
	return join ':', unpack '(A2)6', $s;
}

# The file as a hash: { server => ..., players => [...] }. A missing file is an empty one.
# Forgiving in the same ways as GoSlimPlayer's loader (trailing commas, a bare array).
sub readFile {
	my $path = shift;
	return ({ players => [] }, undef) unless -e $path;
	open my $fh, '<:raw', $path or return (undef, "$path: $!");
	my $txt = do { local $/; <$fh> };
	close $fh;
	$txt =~ s/,(\s*[\]}])/$1/g;
	$txt =~ s/^\s+|\s+\z//g;
	return ({ players => [] }, undef) if $txt eq '';
	$txt = "{$txt}" if $txt !~ /^[\[{]/;
	my $doc = eval { $json->decode($txt) };
	return (undef, "$path: not valid JSON ($@)") unless defined $doc;
	$doc = { players => $doc } if ref $doc eq 'ARRAY';
	return (undef, "$path: not a GoSlimPlayer config") unless ref $doc eq 'HASH';
	$doc->{players} = [] unless ref $doc->{players} eq 'ARRAY';
	return ($doc, undef);
}

# Write it so a GoSlimPlayer watching the file never reads half of it: to a temporary file in
# the same folder, then renamed over the old one.
sub writeFile {
	my ($path, $doc) = @_;
	my $dir = dirname($path);
	eval { make_path($dir) unless -d $dir; 1 } or return "$dir: $@";
	my $tmp = "$path.tmp$$";
	open my $fh, '>:raw', $tmp or return "$tmp: $!";
	print $fh $json->encode($doc);
	close $fh or do { unlink $tmp; return "$tmp: $!" };
	rename $tmp, $path or do { my $e = "$path: $!"; unlink $tmp; return $e };
	return undef;
}

# The file's players as rows for the settings page.
sub rows {
	my $doc = shift;
	my @rows;
	for my $p (@{ $doc->{players} }) {
		next unless ref $p eq 'HASH';
		my $mac = normMAC($p->{mac}) || ($p->{mac} // '');
		my %r = (
			orig    => $mac,
			mac     => $mac,
			name    => $p->{name} // '',
			enabled => (!exists $p->{enabled} || $p->{enabled}) ? 1 : 0,
			buffer_seconds => $p->{buffer_seconds} // '',
			devicename => $p->{devicename} // '',
		);
		$r{$_} = $p->{$_} // '' for keys %{ INT_FIELDS() };
		$r{$_} = !exists $p->{$_} ? 'default' : $p->{$_} ? 'on' : 'off' for @{ TRI_FIELDS() };
		push @rows, \%r;
	}
	return \@rows;
}

# The submitted form applied to the file's contents. Returns the new contents, a list of
# problems (nothing should be written if there are any), and the form as rows (to show it again
# as submitted when there were problems).
#
# Form fields: server, rowCount, and for row i: p<i>_orig (the MAC the row was shown with),
# p<i>_mac, p<i>_name, p<i>_enabled, p<i>_delete, p<i>_<int field>, p<i>_buffer_seconds,
# p<i>_<tri field>. A row with neither a MAC nor a name is the empty "add a player" row.
sub applyForm {
	my ($old, $params) = @_;
	my (@errors, @rows, @players, %seen);

	my %before = map { (normMAC($_->{mac}) || '') => $_ } grep { ref $_ eq 'HASH' } @{ $old->{players} };
	my %new = %$old;

	my $server = trim($params->{server});
	if ($server eq '') {
		delete $new{server};
	}
	elsif ($server =~ /^[A-Za-z0-9.\-]+(?::\d{1,5})?\z|^\[[0-9A-Fa-f:]+\](?::\d{1,5})?\z/) {
		$new{server} = $server;
	}
	else {
		push @errors, "Server: \"$server\" is not a host or host:port";
	}

	my $count = ($params->{rowCount} // 0) =~ /^(\d+)\z/ ? $1 : 0;
	for my $i (0 .. $count - 1) {
		my $f = sub { trim($params->{"p${i}_$_[0]"}) };
		my %r = map { $_ => $f->($_) } qw(orig mac name buffer_seconds), keys %{ INT_FIELDS() };
		$r{$_} = $f->($_) =~ /^(on|off)\z/ ? $1 : 'default' for @{ TRI_FIELDS() };
		$r{enabled} = $params->{"p${i}_enabled"} ? 1 : 0;
		next if $params->{"p${i}_delete"};
		next if $r{mac} eq '' && $r{name} eq '' && $r{orig} eq '';
		push @rows, \%r;

		my $label = $r{name} ne '' ? $r{name} : 'player ' . ($i + 1);
		my $mac = normMAC($r{mac});
		if (!$mac) {
			push @errors, "$label: \"$r{mac}\" is not a MAC address";
			next;
		}
		$r{mac} = $mac;
		if ($seen{$mac}++) {
			push @errors, "$label: MAC $mac is listed twice";
			next;
		}

		# Start from the entry as it was, so keys this page doesn't edit stay.
		my %p = %{ $before{ normMAC($r{orig}) || $mac } || {} };
		delete @p{ @{ OWN_KEYS() } };
		$p{name} = $r{name};   # GoSlimPlayer needs the key; empty uses the renderer's own name
		$p{mac}  = $mac;
		$p{enabled} = JSON::XS::false unless $r{enabled};   # absent means enabled

		for my $k (sort keys %{ INT_FIELDS() }) {
			my $range = INT_FIELDS->{$k};
			next if $r{$k} eq '';
			if ($r{$k} !~ /^-?\d+\z/ || $r{$k} < $range->[0] || $r{$k} > $range->[1]) {
				push @errors, "$label: $k must be a whole number from $range->[0] to $range->[1]";
				next;
			}
			$p{$k} = $r{$k} + 0;
		}
		if ($r{buffer_seconds} ne '') {
			if ($r{buffer_seconds} !~ /^\d+(?:\.\d+)?\z/ || ($r{buffer_seconds} > 0 && $r{buffer_seconds} < 3)) {
				push @errors, "$label: buffer_seconds must be 0 (no limit) or at least 3";
			}
			else {
				$p{buffer_seconds} = $r{buffer_seconds} + 0;
			}
		}
		for my $k (@{ TRI_FIELDS() }) {
			$p{$k} = $r{$k} eq 'on' ? JSON::XS::true : JSON::XS::false if $r{$k} ne 'default';
		}
		push @players, \%p;
	}

	my %ports;
	for my $p (@players) {
		next unless $p->{http_port};
		push @errors, "$p->{mac}: http_port $p->{http_port} is used by another player too"
			if $ports{ $p->{http_port} }++;
	}

	$new{players} = \@players;
	return (\%new, \@errors, \@rows);
}

sub trim {
	my $s = shift // '';
	$s =~ s/^\s+|\s+\z//g;
	return $s;
}

1;
