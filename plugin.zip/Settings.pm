package Plugins::GoSlimPlayer::Settings;

# Settings › Plugins › GoSlimPlayer: where GoSlimPlayer's config file is, the LMS server it
# should use, and its players (UPnP renderers) with their per-player options. Saving writes the
# file; GoSlimPlayer notices and applies the change while it runs.

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(string);

use Plugins::GoSlimPlayer::Config;

my $prefs = preferences('plugin.goslimplayer');
my $log   = logger('plugin.goslimplayer');
my $C     = 'Plugins::GoSlimPlayer::Config';

sub name { Slim::Web::HTTP::CSRF->protectName('PLUGIN_GOSLIMPLAYER') }

sub page { Slim::Web::HTTP::CSRF->protectURI('plugins/GoSlimPlayer/settings/basic.html') }

sub prefs { ($prefs, qw(configFile)) }

sub handler {
	my ($class, $client, $params, @args) = @_;

	my ($rows, $showSubmitted);
	if ($params->{saveSettings}) {
		# The path first, so the rest is saved to the file just chosen.
		my $p = $C->can('trim')->($params->{pref_configFile});
		$params->{pref_configFile} = $p;
		$prefs->set('configFile', $p);

		my $path = Plugins::GoSlimPlayer::Plugin::configFile();
		my ($doc, $err) = $C->can('readFile')->($path);
		if ($err) {
			# Don't replace a file we can't read (a hand edit with a typo, say): say so instead.
			$params->{warning} .= string('PLUGIN_GOSLIMPLAYER_READ_FAILED') . " $err ";
		}
		else {
			my ($new, $errors, $submitted) = $C->can('applyForm')->($doc, $params);
			if (@$errors) {
				$params->{warning} .= string('PLUGIN_GOSLIMPLAYER_NOT_SAVED') . ' ' . join('; ', @$errors) . ' ';
				($rows, $showSubmitted) = ($submitted, 1);   # show the form as it was sent, to correct it
			}
			elsif (my $werr = $C->can('writeFile')->($path, $new)) {
				$params->{warning} .= string('PLUGIN_GOSLIMPLAYER_WRITE_FAILED') . " $werr ";
				($rows, $showSubmitted) = ($submitted, 1);
			}
			else {
				main::INFOLOG && $log->is_info && $log->info("Wrote $path: " . scalar(@{ $new->{players} }) . ' player(s)');
			}
		}
	}

	my $path = Plugins::GoSlimPlayer::Plugin::configFile();
	my ($doc, $err) = $C->can('readFile')->($path);
	if ($err && !$params->{saveSettings}) {
		$params->{warning} .= string('PLUGIN_GOSLIMPLAYER_READ_FAILED') . " $err ";
	}
	$doc ||= { players => [] };
	$rows ||= $C->can('rows')->($doc);

	# What LMS sees of each player: GoSlimPlayer uses the renderer's MAC as the player's.
	for my $r (@$rows) {
		my $c = $r->{mac} && Slim::Player::Client::getClient($r->{mac});
		$r->{lmsName}   = $c ? $c->name : '';
		$r->{connected} = $c && $c->connected ? 1 : 0;
	}

	$params->{gspRows}        = $rows;
	$params->{gspRowCount}    = @$rows + 1;   # and the empty row for adding one
	$params->{gspNewRow}      = scalar @$rows;
	$params->{gspServer}      = $showSubmitted ? ($params->{server} // '') : ($doc->{server} // '');
	$params->{gspServerHint}  = Slim::Utils::Network::serverAddr() . ':3483';
	$params->{gspPath}        = $path;
	$params->{gspDefaultPath} = Plugins::GoSlimPlayer::Plugin::defaultConfigFile();
	$params->{gspFileTime}    = -e $path ? Slim::Utils::DateTime::shortDateF((stat $path)[9]) . ' ' . Slim::Utils::DateTime::timeF((stat $path)[9]) : '';
	$params->{gspTriChoices}  = [qw(default on off)];
	$params->{gspTriFields}   = Plugins::GoSlimPlayer::Config::TRI_FIELDS;

	return $class->SUPER::handler($client, $params, @args);
}

1;
