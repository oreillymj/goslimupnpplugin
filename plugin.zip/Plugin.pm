package Plugins::GoSlimPlayer::Plugin;

# GoSlimPlayer: a settings page in LMS for GoSlimPlayer, the Go Slimproto player that presents
# UPnP/Sonos renderers to LMS as players.
#
# The plugin does not run GoSlimPlayer. It edits GoSlimPlayer's config file (the one given with
# -u), which GoSlimPlayer watches and applies while it runs. The file is the only store: the
# settings page reads it each time it is shown, so hand edits to it are never lost, and keys the
# page doesn't know about (devicename, ip, model from -jsonfile) are kept as they are.
#
# The file is also served read-only at /plugins/GoSlimPlayer/plugin.json, for a GoSlimPlayer
# that runs on another machine than LMS.

use strict;
use base qw(Slim::Plugin::Base);

use File::Spec::Functions qw(catfile);
use HTTP::Date ();

use Slim::Utils::Log;
use Slim::Utils::Prefs;

use Plugins::GoSlimPlayer::Config;

my $log = Slim::Utils::Log->addLogCategory({
	category     => 'plugin.goslimplayer',
	defaultLevel => 'WARN',
	description  => 'PLUGIN_GOSLIMPLAYER',
});

my $prefs = preferences('plugin.goslimplayer');

$prefs->init({
	configFile => '',   # GoSlimPlayer's -u file; empty: defaultConfigFile()
});

sub initPlugin {
	my $class = shift;
	$class->SUPER::initPlugin(@_);

	if (main::WEBUI) {
		require Plugins::GoSlimPlayer::Settings;
		Plugins::GoSlimPlayer::Settings->new;
	}
	Slim::Web::Pages->addRawFunction(qr{^/plugins/GoSlimPlayer/plugin\.json$}, \&_serveConfig);
}

# Where the file goes when no path is set: a folder of its own in LMS's prefs folder, which LMS
# can always write to.
sub defaultConfigFile {
	return catfile(Slim::Utils::OSDetect::dirsFor('prefs'), 'goslimplayer', 'plugin.json');
}

sub configFile { $prefs->get('configFile') || defaultConfigFile() }

# The file as it is on disk, for a GoSlimPlayer that polls it over HTTP.
sub _serveConfig {
	my ($httpClient, $response) = @_;
	my $path = configFile();
	my $body;
	if (open my $fh, '<:raw', $path) {
		local $/;
		$body = <$fh>;
		close $fh;
		$response->code(200);
		$response->header('Last-Modified' => HTTP::Date::time2str((stat $path)[9]));
	}
	else {
		$body = '{"players": []}';
		$response->code(404);
	}
	$response->content_type('application/json');
	$response->header('Cache-Control' => 'no-store');
	$response->header('Content-Length' => length $body);
	Slim::Web::HTTP::addHTTPResponse($httpClient, $response, \$body);
}

1;
